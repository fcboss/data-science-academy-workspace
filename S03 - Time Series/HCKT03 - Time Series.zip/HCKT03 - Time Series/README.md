
Everything you need to know is in this [link](https://docs.google.com/document/d/1teVfwR02uYXEW2tugyszgM9KexkT_FGca5gTEn4ymsY/edit?usp=sharing).

